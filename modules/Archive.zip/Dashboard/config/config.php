<?php
return [
    'name' => 'Dashboard',
];

